from selenium import webdriver
from selenium.webdriver.chrome.options import Options 
from selenium.webdriver.common.by import By
import time 
chrome_options = Options() 
chrome_options.add_argument("--headless") 
chrome_options.add_argument("--no-sandbox") 
chrome_options.add_argument("--disable-dev-shm-usage") 
driver = webdriver.Chrome(options=chrome_options) driver.get("http://192.168.49.2:30001") 
print("✅ 进入商城首页")
time.sleep(3) 
products = driver.find_elements(By.CLASS_NAME, "product") 
print(f"📦 商品数：{len(products)}") 
if products:
    products[0].click() print("🛒 进入商品详情页")
    time.sleep(2)
    add_btn =  driver.find_element(By.XPATH, '//button[contains(text(), "Add To Cart")]') 
    add_btn.click() 
    print("✔️ 成功加入购物车") 
    driver.get("http://8.140.214.230/cart")
    time.sleep(2)
driver.save_screenshot("cart_page.png") 
driver.quit()
print("📸 已保存截图 cart_page.png")
