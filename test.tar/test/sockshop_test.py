from selenium import webdriver
from selenium.webdriver.common.by import By
import subprocess
import time

# 获取前端IP的正确方法
def get_frontend_ip():
    cmd = "kubectl get svc front-end -n sock-shop -o jsonpath='{.status.loadBalancer.ingress[0].ip}'"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode == 0:
        return result.stdout.strip()
    else:
        raise Exception("获取IP失败: " + result.stderr)

# 配置浏览器选项
options = webdriver.ChromeOptions()
options.add_argument('--headless')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

driver = webdriver.Chrome(options=options)

try:
    frontend_ip = get_frontend_ip()
    url = f"http://{frontend_ip}:80"
    print("测试地址:", url)

    # 测试首页加载
    driver.get(url)
    time.sleep(3)
    assert "Sock Shop" in driver.title
    print("首页加载测试通过 ✅")
  
    # 剩余测试代码保持不变...
  
finally:
    driver.quit()
